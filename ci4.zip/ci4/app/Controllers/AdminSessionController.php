<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class AdminSessionController extends Controller
{
    protected $session;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $this->session = session();

        // Routes that do not require admin login
        $allowedRoutes = [
            'adlogin', // for AdminController (admin/index and admin/authenticate assumed allowed)
        ];

        // Get the current controller from the URL
        $currentController = strtolower(service('router')->controllerName());
        $currentController = explode('\\', $currentController); // e.g., App\Controllers\AdminController
        $currentController = strtolower(str_replace('controller', '', end($currentController)));

        // If admin is not logged in and not accessing allowed controller, redirect
        if (!$this->session->get('Alogged_in') && !in_array($currentController, $allowedRoutes)) {
            header('Location: ' . base_url('/admin/index'));
            exit;
        }
    }
}
