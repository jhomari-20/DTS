<?php

namespace App\Controllers;

use App\Models\AccountModel;
use CodeIgniter\Controller;

class LoginController extends BaseController
{
    public function index()
    {
        return view('user/login'); // Load the login form (your current HTML view)
    }

    public function authenticate()
    {
        helper(['form', 'url']);

        // Get input values
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $remember = $this->request->getPost('remember');

        // Form validation
        $rules = [
            'username' => 'required|min_length[3]|max_length[255]',
            'password' => 'required|min_length[6]',
        ];

        if (!$this->validate($rules)) {
            // Validation failed
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Check if the user exists
        $accountModel = new AccountModel();
        $user = $accountModel->getUserByUsername($username);

        if (!$user || $user['password'] !== $password) {
            // Invalid username or password
            return redirect()->back()->with('error', 'Invalid username or password.');
        }


        // Set session data
        $session = session();
        $sessionData = [
            'user_id' => $user['id'],
            'fullname' => $user['fullname'],
            'username' => $user['username'],
            'logged_in' => true
        ];

        $session->set($sessionData);

        // Handle "Remember me" functionality
        if ($remember) {
            // You can set a cookie for a longer session here, or use JWT for persistent sessions
        }

        return redirect()->to('/user/index'); // Redirect to the dashboard after successful login
    }

    public function logout()
    {
        $session = session();
        $session->destroy();  // Destroy the session to log the user out
        
        // Redirect to the login page or home page
        return redirect()->to('/login');  // Redirect to the login page
    }
}
