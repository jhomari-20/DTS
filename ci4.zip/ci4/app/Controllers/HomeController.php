<?php

namespace App\Controllers;

use App\Models\DocumentModel;
use App\Models\AccountModel;

class HomeController extends BaseController
{
    /**
     * Show user dashboard with document statistics.
     */
    public function index()
    {
        $session = session();
        $userId = $session->get('user_id');
    
        $accountModel = new AccountModel();
        $user = $accountModel->find($userId);
    
        if (!$user) {
            return redirect()->to('/login')->with('error', 'User not found.');
        }
    
        $zipcode = $user['zip_code'];
        $documentModel = new DocumentModel();
    
        // Basic document counts
        $totalDocuments = $documentModel->where('zipcode', $zipcode)->countAllResults();
        $totalApproved  = $documentModel->where('zipcode', $zipcode)->where('status', 'approved')->countAllResults();
        $totalPending   = $documentModel->where('zipcode', $zipcode)->where('status !=', 'approved')->countAllResults();
    
        // Date ranges for this and last month
        $thisMonthStart = date('Y-m-01');
        $thisMonthEnd   = date('Y-m-t');
    
        $lastMonthStart = date('Y-m-01', strtotime('first day of last month'));
        $lastMonthEnd   = date('Y-m-t', strtotime('last day of last month'));
    
        // Monthly counts by status
        $totalThisMonth    = $documentModel->where('zipcode', $zipcode)->countByDateRange($thisMonthStart, $thisMonthEnd);
        $totalLastMonth    = $documentModel->where('zipcode', $zipcode)->countByDateRange($lastMonthStart, $lastMonthEnd);
    
        $approvedThisMonth = $documentModel->where('zipcode', $zipcode)->where('status', 'approved')->countByDateRange($thisMonthStart, $thisMonthEnd);
        $approvedLastMonth = $documentModel->where('zipcode', $zipcode)->where('status', 'approved')->countByDateRange($lastMonthStart, $lastMonthEnd);
    
        $pendingThisMonth  = $documentModel->where('zipcode', $zipcode)->where('status !=', 'approved')->countByDateRange($thisMonthStart, $thisMonthEnd);
        $pendingLastMonth  = $documentModel->where('zipcode', $zipcode)->where('status !=', 'approved')->countByDateRange($lastMonthStart, $lastMonthEnd);
    
        // Helper function for percentage
        function getChange($current, $previous)
        {
            if ($previous == 0) return $current > 0 ? 100 : 0;
            return (($current - $previous) / $previous) * 100;
        }
    
        // Calculate all percent changes
        $data = [
            'totalDocuments'         => $totalDocuments,
            'totalApproved'          => $totalApproved,
            'totalPending'           => $totalPending,
            'percentChangeDocuments' => getChange($totalThisMonth, $totalLastMonth),
            'percentChangeApproved'  => getChange($approvedThisMonth, $approvedLastMonth),
            'percentChangePending'   => getChange($pendingThisMonth, $pendingLastMonth),
        ];
    
        return view('user/dashboard', $data);
    }
    
    /**
     * Show document creation form.
     */
    public function create()
    {
        return view('user/add');
    }

    /**
     * Show documents page.
     */
    public function document()
    {
        return view('user/documents');
    }

    /**
     * Show document edit form.
     */
    public function edit()
    {
        return view('user/edit');
    }

    /**
     * Store a new document record.
     */
    public function store()
    {
        $request = service('request');
        $validation = \Config\Services::validation();
    
        $validation->setRules([
            'fullname'     => 'required',
            'doc_type'     => 'required',
            'employee_id'  => 'required',
            'date'         => 'required',
        ]);
    
        if (!$validation->withRequest($request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
    
        // Get current user ID from session
        $session = session();
        $userId = $session->get('user_id');
    
        // Get user's zipcode
        $accountModel = new \App\Models\AccountModel();
        $user = $accountModel->find($userId);
        $zipcode = $user['zip_code'] ?? null;

        $model = new \App\Models\DocumentModel();
        $data = [
            'fullname'    => $this->request->getPost('fullname'),
            'doc_type'    => $this->request->getPost('doc_type'),
            'employee_id' => $this->request->getPost('employee_id'),
            'date'        => $this->request->getPost('date'),
            'zipcode'     => $zipcode, // include user's zipcode here
        ];
    
        if ($model->insert($data)) {
            return redirect()->to('/user/create')->with('success', 'Request saved successfully.');
        }
    
        return redirect()->back()->withInput()->with('error', 'Failed to save the request.');
    }
    
}
