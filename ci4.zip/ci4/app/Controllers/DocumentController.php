<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\DocumentModel;
use CodeIgniter\API\ResponseTrait;
use Endroid\QrCode\QrCode;


class DocumentController extends BaseController
{
    use ResponseTrait;

    public function index()
        {
            $session = session();
            $userId = $session->get('user_id');

            $accountModel = new \App\Models\AccountModel();
            $user = $accountModel->find($userId);

            if (!$user || empty($user['zip_code'])) {
                return redirect()->to('/login')->with('error', 'Unauthorized access.');
            }

            $zipCode = $user['zip_code'];

            $documentModel = new DocumentModel();
            $data['documents'] = $documentModel->getDocumentsWithLatestReceivedBy($zipCode);            

            return view('user/documents', $data);
        }

    public function delete($id)
        {
            $documentModel = new DocumentModel();
            $document = $documentModel->find($id);
        
            if ($document) {
                $documentModel->delete($id);
                return $this->response->setJSON(['success' => true, 'message' => 'Document deleted successfully.']);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Document not found.']);
            }
        }
}