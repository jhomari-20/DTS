<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class OfficeController extends BaseController
{
    public function index()
    {
        //
    }
    public function create()
    {
        return view('admin/dashboard');
    }
    public function store()
    {
        $request = $this->request;
        
        // Get JSON input
        $json = $request->getJSON();
        $documentId = $json->id ?? null;
        $officeReceived = $json->office_received ?? null;

        if (!$documentId || !$officeReceived) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Missing document ID or office_received field.',
            ]);
        }

        // Load the Document model
        $documentModel = new DocumentModel();
        $existingDocument = $documentModel->find($documentId);

        if ($existingDocument) {
            // Update only the office_received field
            $data = [
                'office_received' => $officeReceived
            ];

            $documentModel->update($documentId, $data);

            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Office received field updated successfully.',
                'data' => $data,
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Document not found.',
            ]);
        }
    }
}
