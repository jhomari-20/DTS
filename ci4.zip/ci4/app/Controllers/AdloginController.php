<?php
namespace App\Controllers;

use App\Models\OfficeModel;
use App\Models\Document_StatusesModel;

class AdloginController extends AdminSessionController
{
    public function index()
    {
        return view('admin/login'); // Show admin login page
    }

    public function authenticate()
    {
        $session = session();
        $model = new OfficeModel();
    
        $department = $this->request->getPost('department');
        $password = $this->request->getPost('password');
        $user = $model->where('department', $department)->first();
    
        if ($user) {
            if ($password === $user['password']) {
                $sessionData = [
                    'id'         => $user['id'],
                    'department' => $user['department'],
                    'Alogged_in' => true
                ];
                $session->set($sessionData);

                $session->setFlashdata('success', 'Login successful! Welcome, ' . $user['department']);
                return redirect()->to('/admin/dashboard');
            } else {
                $session->setFlashdata('error', 'Invalid password.');
                return redirect()->to('/admin/index');
            }
        } else {
            $session->setFlashdata('error', 'Department not found.');
            return redirect()->to('/admin/index');
        }
    }

    public function logout()
    {
        session()->destroy();  // Destroy the session
        return redirect()->to('/admin/index')->with('success', 'Successfully logged out');
    }
  
}
