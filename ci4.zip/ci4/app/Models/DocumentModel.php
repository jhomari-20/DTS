<?php namespace App\Models;

use CodeIgniter\Model;

class DocumentModel extends Model
{
    protected $table = 'documents';
    protected $allowedFields = ['id', 'zipcode', 'fullname', 'doc_type', 'employee_id', 'qr_code', 'date', 'status'];
    
    public function countByDateRange($startDate, $endDate)
    {
        return $this->where('date >=', $startDate)
                    ->where('date <=', $endDate)
                    ->countAllResults();
    }
    public function getDocumentsWithLatestReceivedBy($zipCode)
    {
        $db = \Config\Database::connect();
    
        return $db->table('documents d')
            ->select('d.id, d.doc_type, d.fullname, d.date, d.status, ds.received_by')
            ->join(
                '(SELECT document_id, received_by FROM documents_statuses 
                  WHERE (document_id, date) IN 
                        (SELECT document_id, MAX(date) FROM documents_statuses GROUP BY document_id)
                ) ds',
                'ds.document_id = d.id',
                'left'
            )
            ->where('d.zipcode', $zipCode)
            ->get()
            ->getResultArray();
    }
    
    

}
