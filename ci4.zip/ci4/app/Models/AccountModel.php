<?php

namespace App\Models;

use CodeIgniter\Model;

class AccountModel extends Model
{
  
    protected $table = 'accounts';  // Your table name
    protected $primaryKey = 'id';   // Assuming 'id' is the primary key
    protected $allowedFields = ['fullname', 'username', 'password']; // Fields you want to allow for updating/inserting

    
    public function getUserByUsername($username)
    {
        return $this->where('username', $username)->first(); // Get the first match by username
    }
}
