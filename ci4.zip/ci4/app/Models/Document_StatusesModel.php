<?php
namespace App\Models;

use CodeIgniter\Model;

class Document_StatusesModel extends Model
{
    protected $table = 'documents_statuses';
    protected $primaryKey = 'id';
    protected $allowedFields = ['document_id', 'received_by', 'status', 'date'];
}
