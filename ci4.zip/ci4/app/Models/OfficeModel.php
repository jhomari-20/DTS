<?php

namespace App\Models;

use CodeIgniter\Model;

class OfficeModel extends Model
{
    protected $table = 'office';  // your DB table
    protected $primaryKey = 'id';
    protected $allowedFields = ['department', 'password']; // add more fields as needed
}
