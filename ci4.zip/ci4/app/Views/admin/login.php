<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Scanning Portal | Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --accent: #10b981;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #94a3b8;
            --gray-light: #e2e8f0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        body {
            background-color: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        
        .login-container {
            display: flex;
            width: 100%;
            max-width: 1200px;
            margin: auto;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            overflow: hidden;
        }
        
        .graphic-side {
            flex: 1.2;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 3rem;
            position: relative;
            overflow: hidden;
        }
        
        .graphic-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
        }
        
        .graphic-content {
            z-index: 1;
            color: white;
            text-align: center;
            max-width: 500px;
        }
        
        .qr-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .graphic-content h1 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 1.2rem;
        }
        
        .graphic-content p {
            font-size: 1.05rem;
            line-height: 1.6;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        
        .features {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 2.5rem;
        }
        
        .feature {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(5px);
            padding: 1rem;
            border-radius: 8px;
            width: 160px;
        }
        
        .feature i {
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
            color: var(--accent);
        }
        
        .feature h3 {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }
        
        .feature p {
            font-size: 0.8rem;
            margin: 0;
            opacity: 0.8;
        }
        
        .form-side {
            flex: 1;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 3rem 2rem;
        }
        
        .login-form {
            width: 100%;
            max-width: 380px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 2.5rem;
        }
        
        .logo-icon {
            font-size: 1.8rem;
            color: var(--primary);
            margin-right: 0.8rem;
        }
        
        .logo-text {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark);
        }
        
        .logo-text span {
            color: var(--primary);
        }
        
        .form-header {
            margin-bottom: 2rem;
        }
        
        .form-header h2 {
            font-size: 1.7rem;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .form-header p {
            color: var(--gray);
            font-size: 0.95rem;
        }
        
        .input-group {
            margin-bottom: 1.5rem;
            position: relative;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-weight: 500;
            font-size: 0.95rem;
        }
        
        .input-group input {
            width: 100%;
            padding: 0.9rem 1rem;
            border: 1px solid var(--gray-light);
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.2s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }
        
        .input-group .input-icon {
            position: absolute;
            right: 1rem;
            top: 2.6rem;
            color: var(--gray);
            cursor: pointer;
        }
        
        .options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.8rem;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
        }
        
        .remember-me input {
            margin-right: 0.5rem;
            accent-color: var(--primary);
        }
        
        .remember-me label {
            font-size: 0.9rem;
            color: var(--dark);
        }
        
        .forgot-password {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
        }
        
        .login-button {
            width: 100%;
            padding: 1rem;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 1.5rem;
        }
        
        .login-button:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
        }
        
        .qr-login-option {
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .qr-login-button {
            display: inline-flex;
            align-items: center;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            transition: all 0.2s;
        }
        
        .qr-login-button:hover {
            color: var(--primary-dark);
        }
        
        .qr-login-button i {
            margin-right: 0.5rem;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                max-width: 100%;
                border-radius: 0;
            }
            
            .graphic-side {
                padding: 2rem 1.5rem;
            }
            
            .features {
                display: none;
            }
            
            .form-side {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="graphic-side">
            <div class="graphic-overlay"></div>
            <div class="graphic-content">
                <div class="qr-icon">
                    <i class="fas fa-qrcode"></i>
                </div>
                <h1>Document Scanning Portal</h1>
                <p>Securely access your department's document scanning system and manage QR-coded documents with ease.</p>
                
                <div class="features">
                    <div class="feature">
                        <i class="fas fa-shield-alt"></i>
                        <h3>Secure Access</h3>
                        <p>Enterprise-grade security for all documents</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-bolt"></i>
                        <h3>Quick Processing</h3>
                        <p>Rapid QR code scanning technology</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-chart-line"></i>
                        <h3>Track Analytics</h3>
                        <p>Monitor document processing metrics</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-side">
            <div class="login-form">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <div class="logo-text">
                        Scan<span>Portal</span>
                    </div>
                </div>
                <div class="form-header">
                    <h2>Department Login</h2>
                    <p>Enter your credentials to access the scanning system</p>
                </div>
            
                <form method="post" action="<?= site_url('admin/authenticate') ?>">
                <?php if (session()->getFlashdata('success')) : ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('error')) : ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>

                    <div class="input-group">
                        <label for="department">Department</label>
                        <input type="text" id="department" name="department" placeholder="e.g. IT, HR, Admin">
                        <i class="fas fa-envelope input-icon"></i>
                    </div>
                    <div class="input-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your Password">
                        <i class="fas fa-eye input-icon" id="togglePassword"></i>
                    </div>
                    <div class="options">
                        <div class="remember-me">
                            <input type="checkbox" id="remember">
                            <label for="remember">Remember this device</label>
                        </div>
                        <a href="#" class="forgot-password">Forgot password?</a>
                    </div>
                    <button type="submit" class="login-button">Sign In</button>

                    <div class="qr-login-option">
                        <a href="#" class="qr-login-button">
                            <i class="fas fa-qrcode"></i>
                            Sign in with QR code instead
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
        // Toggle password visibility
        const togglePassword = document.getElementById('togglePassword');
        const password = document.getElementById('password');
        
        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>