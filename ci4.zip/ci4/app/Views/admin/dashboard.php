<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocScan Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-light: #6366f1;
            --primary-dark: #4338ca;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #94a3b8;
            --light-gray: #e2e8f0;
            --radius: 0.5rem;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
            background-color: #f1f5f9;
            color: var(--dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.5;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        /* Header */
        header {
            background: white;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 600;
            font-size: 1.25rem;
            color: var(--primary);
        }

        .logo i {
            font-size: 1.5rem;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.25rem;
            border-radius: var(--radius);
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            white-space: nowrap;
        }

        .btn i {
            font-size: 1rem;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: white;
            color: var(--dark);
            box-shadow: inset 0 0 0 1px var(--light-gray);
        }

        .btn-secondary:hover {
            box-shadow: inset 0 0 0 1px var(--gray);
            transform: translateY(-1px);
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }

        /* Main Sections */
        .scanner-section, .results-section, .documents-section {
            padding: 2rem 0;
            flex: 1;
        }

        .results-section {
            display: none;
        }

        /* Scanner Container */
        .scanner-container {
            background: white;
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
            max-width: 800px;
            margin: 0 auto;
        }

        .scanner-title {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
            text-align: center;
        }

        .scanner-description {
            color: var(--gray);
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .scanner-box {
            position: relative;
            width: 100%;
            max-width: 500px;
            margin: 0 auto 2rem;
            aspect-ratio: 1;
            border-radius: var(--radius);
            overflow: hidden;
            background: var(--dark);
        }

        #scanner-video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .scanner-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                to bottom,
                rgba(0, 0, 0, 0.5) 0%,
                rgba(0, 0, 0, 0) 30%,
                rgba(0, 0, 0, 0) 70%,
                rgba(0, 0, 0, 0.5) 100%
            );
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .scan-line {
            width: 80%;
            height: 2px;
            background: var(--primary-light);
            box-shadow: 0 0 10px var(--primary-light);
            position: absolute;
            animation: scan 2s infinite ease-in-out;
        }

        @keyframes scan {
            0% { top: 20%; }
            100% { top: 80%; }
        }

        .scanner-controls {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* Results Card */
        .result-card {
            background: white;
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
            max-width: 600px;
            margin: 0 auto;
            text-align: center;
        }

        .result-icon {
            font-size: 4rem;
            color: var(--success);
            margin-bottom: 1rem;
        }

        .result-title {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .result-message {
            color: var(--gray);
            margin-bottom: 2rem;
        }

        .document-info {
            background: #f8fafc;
            border-radius: var(--radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            text-align: left;
        }

        .document-info p {
            margin-bottom: 0.75rem;
            display: flex;
            gap: 0.5rem;
        }

        .document-info p:last-child {
            margin-bottom: 0;
        }

        .document-info strong {
            min-width: 100px;
            display: inline-block;
            color: var(--dark);
        }

        /* Status Badges */
        .status {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .status-received {
            background: #d1fae5;
            color: #065f46;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        /* Documents Table */
        .section-title {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            color: var(--dark);
        }

        .dashboard {
            background: white;
            border-radius: var(--radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            overflow-x: auto;
        }

        .document-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }

        .document-table th,
        .document-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }

        .document-table th {
            font-weight: 600;
            color: var(--dark);
            background: #f8fafc;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }

        .document-table tr:last-child td {
            border-bottom: none;
        }

        .document-table tr:hover td {
            background: #f8fafc;
        }

        /* Footer */
        footer {
            background: var(--dark);
            color: white;
            padding: 2rem 0;
            margin-top: auto;
        }

        .footer-content {
            text-align: center;
        }

        .footer-logo {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: white;
        }

        .footer-content p {
            color: var(--light-gray);
            margin-bottom: 0.5rem;
        }

        .copyright {
            font-size: 0.875rem;
            color: var(--gray);
        }
        /* Styling for the department name */
        .welcome-message{
            color: #fff;
            font-size: 1.2rem;
            font-weight: bold;
            margin-left: 20px;
            padding: 5px 10px;
            background-color: #4CAF50; /* Green background */
            border-radius: 5px;
            display: inline-block;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .scanner-container, .result-card {
                padding: 1.5rem;
            }
            
            .document-info {
                padding: 1rem;
            }
            
            .document-info p {
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .document-info strong {
                min-width: auto;
            }
            
            .dashboard {
                padding: 0.5rem;
            }
            
            .document-table th,
            .document-table td {
                padding: 0.75rem 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .scanner-title {
                font-size: 1.25rem;
            }
            
            .scanner-controls {
                flex-direction: column;
                width: 100%;
            }
            
            .scanner-controls .btn {
                width: 100%;
            }
            
            .result-title {
                font-size: 1.25rem;
            }
            
            .document-table {
                font-size: 0.75rem;
            }
            
            .document-table th,
            .document-table td {
                padding: 0.5rem 0.25rem;
            }
        }

        /* Animation for scan success */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.3s ease-out forwards;
        }
    </style>
</head>
<body>
    <!-- Header -->
   <header>
    <div class="container">
        <nav>
            <div class="logo">
                <i class="fas fa-qrcode"></i>
                <span>DocScan Pro</span>
            </div>
            <!-- Display welcome message based on the session -->
            <div class="welcome-message">
                <?php if (session()->get('Alogged_in')): ?>
                    <span>Welcome, <?= esc(session()->get('department')); ?>!</span>
                <?php else: ?>
                    <span>Welcome, Guest!</span>
                <?php endif; ?>
            </div>
            <form action="/admin/logout" method="POST" style="display: inline;">
                <button type="submit" class="btn btn-danger btn-sm" style="margin-left: 10px;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </nav>
    </div>
</header>


    <!-- Scanner Section -->
    <section class="scanner-section" id="scanner-section">
        <div class="container">
            <div class="scanner-container">
                <h2 class="scanner-title">Document QR Code Scanner</h2>
                <p class="scanner-description">Scan document QR codes to automatically update their status to "Received" in your tracking system.</p>
                
                <div class="scanner-box">
                    <video id="scanner-video" playsinline></video>
                    <div class="scanner-overlay">
                        <div class="scan-line"></div>
                    </div>
                </div>
                
                <div class="scanner-controls">
                    <button id="start-scanner" class="btn btn-primary">
                        <i class="fas fa-play"></i> Start Scanner
                    </button>
                    <button id="stop-scanner" class="btn btn-secondary" disabled>
                        <i class="fas fa-stop"></i> Stop Scanner
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Results Section -->
    <section class="results-section" id="results-section">
        <div class="container">
            <div class="result-card fade-in">
                <div class="result-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3 class="result-title">Document Successfully Received!</h3>
                <p class="result-message">The document status has been updated in our system.</p>
                
                <div class="document-info" id="document-info">
                    <!-- Dynamically populated with document details -->
                </div>
                
                <button id="scan-another" class="btn btn-primary">
                    <i class="fas fa-qrcode"></i> Scan Another Document
                </button>
            </div>
        </div>
    </section>

    <!-- Documents Table Section -->
    <section class="documents-section">
        <div class="container">
            <h2 class="section-title">Recent Documents</h2>
            <div class="dashboard">
                <table class="document-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="documents-table">
                        <!-- Sample data - in a real app this would come from a database -->
                        <tr>
                            <td>#DOC-1001</td>
                            <td>Contract</td>
                            <td>John Smith</td>
                            <td>2023-06-15</td>
                            <td><span class="status status-received">Received</span></td>
                        </tr>
                        <tr>
                            <td>#DOC-1002</td>
                            <td>Invoice</td>
                            <td>Sarah Johnson</td>
                            <td>2023-06-16</td>
                            <td><span class="status status-pending">Pending</span></td>
                        </tr>
                        <tr>
                            <td>#DOC-1003</td>
                            <td>Proposal</td>
                            <td>Michael Brown</td>
                            <td>2023-06-17</td>
                            <td><span class="status status-pending">Pending</span></td>
                        </tr>
                        <tr>
                            <td>#DOC-1004</td>
                            <td>Report</td>
                            <td>Emily Davis</td>
                            <td>2023-06-18</td>
                            <td><span class="status status-received">Received</span></td>
                        </tr>
                        <tr>
                            <td>#DOC-1005</td>
                            <td>Application</td>
                            <td>David Wilson</td>
                            <td>2023-06-19</td>
                            <td><span class="status status-pending">Pending</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">DocScan Pro</div>
                <p>Premium document tracking and QR code scanning solution</p>
                <p class="copyright">&copy; 2023 DocScan Pro. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- QR Scanner Library -->
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
    
    <script>
    const video = document.getElementById('scanner-video');
    const startBtn = document.getElementById('start-scanner');
    const stopBtn = document.getElementById('stop-scanner');
    const scanAnotherBtn = document.getElementById('scan-another');
    const resultsSection = document.getElementById('results-section');
    const scannerSection = document.getElementById('scanner-section');
    const documentInfo = document.getElementById('document-info');
    const documentsTable = document.getElementById('documents-table');

    let scannerActive = false;
    let stream = null;
    let interval = null;
    let scannedData = null;

    startBtn.addEventListener('click', async () => {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: "environment" }
            });
            video.srcObject = stream;
            video.setAttribute('playsinline', true);
            video.play();

            scannerActive = true;
            startBtn.disabled = true;
            stopBtn.disabled = false;

            interval = setInterval(scanQRCode, 100);
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert("Could not access the camera.");
        }
    });

    stopBtn.addEventListener('click', () => stopScanner());

    scanAnotherBtn.addEventListener('click', () => {
        resultsSection.style.display = 'none';
        scannerSection.style.display = 'block';
        startBtn.click();
    });

    function scanQRCode() {
        if (!scannerActive || video.readyState !== video.HAVE_ENOUGH_DATA) return;

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code) {
            handleScannedDocument(code.data);
        }
    }

    function handleScannedDocument(data) {
        stopScanner();

        try {
            scannedData = JSON.parse(data);
            const { id, fullname, doc_type } = scannedData;

            documentInfo.innerHTML = `
                <p><strong>Document ID:</strong> #${id}</p>
                <p><strong>Full Name:</strong> ${fullname}</p>
                <p><strong>Document Type:</strong> ${doc_type}</p>
                <p><strong>Status:</strong> <span class="status status-received">Ready to Save</span></p>
                <button id="saveDocument" class="btn btn-success">Received</button>
            `;

            document.getElementById('saveDocument').addEventListener('click', saveDocumentToServer);
            resultsSection.style.display = 'block';
            scannerSection.style.display = 'none';

        } catch (e) {
            documentInfo.innerHTML = `<p class="error-message"><i class="fas fa-exclamation-circle"></i> Invalid QR code data.</p>`;
            resultsSection.style.display = 'block';
            scannerSection.style.display = 'none';
        }
    }

    function saveDocumentToServer() {
        if (!scannedData) return;

        fetch('saveDocument', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(scannedData)
        })
        .then(res => res.json())
        .then(response => {
            if (response.status === 'success') {
                alert('Document saved!');
                loadRecentDocuments();
            } else {
                alert('Error: ' + response.message);
            }
        })
        .catch(err => console.error('Error:', err));
    }

    function stopScanner() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        clearInterval(interval);
        scannerActive = false;
        startBtn.disabled = false;
        stopBtn.disabled = true;
    }

    function loadRecentDocuments() {
        fetch('/documents/recent')
            .then(res => res.json())
            .then(data => {
                let tableHTML = '';
                data.forEach(doc => {
                    tableHTML += `
                        <tr>
                            <td>#${doc.id}</td>
                            <td>${doc.doc_type}</td>
                            <td>${doc.fullname}</td>
                            <td>${doc.date}</td>
                            <td><span class="status status-${doc.status.toLowerCase()}">${doc.status}</span></td>
                        </tr>
                    `;
                });
                documentsTable.innerHTML = tableHTML;
            });
    }

    loadRecentDocuments();

    document.addEventListener('visibilitychange', () => {
        if (document.hidden && scannerActive) stopScanner();
    });
</script>


</body>
</html>