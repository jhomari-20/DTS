<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack Pro | Premium Document Tracking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/documents.css') ?>">
    <style>
    /* Style for the filter button */
    .filter-btn {
        position: relative;
        width: 250px;
        margin: 0 auto;
    }

    /* Style for the select dropdown */
    #filterDocType {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        border-radius: 8px;
        border: 1px solid #ccc;
        background-color: #f9f9f9;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    /* Hover effect for the select dropdown */
    #filterDocType:hover {
        border-color: #007bff;
        background-color: #e9f1ff;
    }

    /* Focus effect for the select dropdown */
    #filterDocType:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }

    /* Style for the option elements */
    #filterDocType option {
        padding: 10px;
        font-size: 10px;
    }
    .modal-actions .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    transition: all 0.3s ease;
    text-decoration: none;
}

/* Primary Button (Print) */
.modal-actions .btn-primary {
    background-color: #007bff;
    color: white;
    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.2);
}

.modal-actions .btn-primary:hover {
    background-color: #0056b3;
    box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);
}

/* Secondary Button (Close) */
.modal-actions .btn-secondary {
    background-color: #e4e6eb;
    color: #333;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.modal-actions .btn-secondary:hover {
    background-color: #d4d6da;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}

</style>
</head>
<body>
    <?= view('templates/sidebar'); ?>
    
    <div class="main-content">
    <?= view('templates/header'); ?>
        <!-- Dashboard Section -->
        <section class="container">
            <div class="dashboard">
                <div class="dashboard-header">
                    <h2 class="dashboard-title">Document Tracking</h2>
                    <div class="search-filter">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search documents..." onkeyup="filterTable()">
                        </div>
                        <div class="filter-btn">
                            <select id="filterDocType" onchange="filterTable()">
                                <option value="">All Document Types</option>
                                <option value="Performance Review">Performance Review</option>
                                <option value="Employment Contract">Employment Contract	</option>
                                <option value="Training Materials">Training Materials</option>
                                <option value="Payroll Records">Payroll Records</option>
                            
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Document Table -->
            <div class="table-container">
                <table class="document-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Document Type</th>
                                <th>Full Name</th>
                                <th>Date</th>
                                <th>Office Received</th>
                                <!-- <th>Status</th> -->
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $counter= 1; ?>
                            <?php if (!empty($documents) && is_array($documents)): ?>
                                <?php foreach ($documents as $document): ?>
                                    <tr>
                                        <td><?= $counter++ ?></td>
                                        <td><?= esc($document['doc_type']) ?></td>
                                        <td><?= esc($document['fullname']) ?></td>
                                        <td><?= esc($document['date']) ?></td>
                                        <td><?= esc($document['received_by'] ?? 'Pending') ?></td>
                                        <!-- <td>
                                            <?php 
                                                $statusClass = '';
                                                switch (strtolower($document['status'])) {
                                                    case 'pending':
                                                        $statusClass = 'status-pending';
                                                        break;
                                                    case 'approved':
                                                        $statusClass = 'status-approved';
                                                        break;
                                                    case 'rejected':
                                                        $statusClass = 'status-rejected';
                                                        break;
                                                }
                                            ?>
                                            <span class="status <?= $statusClass ?>">
                                                <?= esc($document['status']) ?>
                                            </span>
                                        </td> -->
                                        <td>
                                            <button class="action-btn" onclick="openQRModal('<?= esc($document['id']) ?>', '<?= esc($document['fullname']) ?>', '<?= esc($document['doc_type']) ?>')">
                                                <i class="fas fa-qrcode"></i>
                                            </button>
                                            <button class="action-btn">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button onclick="deleteDocument(<?= $document['id']; ?>)" class="action-btn">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7">No documents found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>     
        </section> 
        <!-- QR Code Modal -->
        <div id="qrModal" class="modal">
            <div class="modal-content">
                <span class="close-btn" onclick="closeQRModal()">&times;</span>
                <div class="modal-header">
                    <h3>Document QR Code</h3>
                    <p id="documentIdDisplay"></p>
                </div>
                <div class="qr-code">
                    <img id="qrImage" src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=DOC-1001" alt="QR Code">
                </div>
                <div class="modal-actions">
                <div class="modal-actions">
                    <button class="btn btn-primary" onclick="printQR()">
                        <i class="fas fa-print"></i> Print
                    </button>
                    <button class="btn btn-secondary" onclick="closeQRModal()">
                        <i class="fas fa-times"></i> Close
                    </button>
                </div>

                </div>
            </div>
        </div>
    </div>
    
    <script src="<?= base_url('assets/js/script.js'); ?>"></script>
   
   <script>
        function filterTable() {
                // Get the value of the search input field
                let searchInput = document.getElementById('searchInput').value.toLowerCase();
                
                // Get the selected document type filter
                let filterDocType = document.getElementById('filterDocType').value.toLowerCase();

                // Get the table and its rows
                let table = document.querySelector('.document-table');
                let rows = table.querySelectorAll('tbody tr');

                // Loop through all table rows and hide those that don't match the search term and filter
                rows.forEach(row => {
                    let cells = row.getElementsByTagName('td');
                    let matchSearch = false;
                    let matchType = false;

                    // Loop through each cell in the row to check for search term match
                    for (let i = 0; i < cells.length; i++) {
                        if (cells[i].textContent.toLowerCase().includes(searchInput)) {
                            matchSearch = true;
                        }
                    }

                    // Check if the document type column (second column) matches the selected filter
                    let documentTypeCell = row.cells[1].textContent.toLowerCase();
                    if (filterDocType === '' || documentTypeCell.includes(filterDocType)) {
                        matchType = true;
                    }

                    // Show or hide the row based on whether both search and filter conditions are met
                    if (matchSearch && matchType) {
                        row.style.display = ''; // Show the row
                    } else {
                        row.style.display = 'none'; // Hide the row
                    }
                });
            }


    </script>
</body>
</html>
