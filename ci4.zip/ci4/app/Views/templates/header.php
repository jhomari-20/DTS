<?php
$session = session();
$fullname = $session->get('fullname');
?>
<div class="doc-header-wrapper">
    <div class="doc-header">
        <div class="doc-header-content">
            <div class="doc-header-title">
                <h1>Dashboard</h1>
                <p>Welcome back, <?= esc($fullname) ?>! Here's what's happening with your documents.</p>
            </div>
            
            <div class="doc-header-user-profile">
                <div class="doc-header-avatar"><?= strtoupper(substr($fullname, 0, 2)) ?></div>
                <div class="doc-header-user-details">
                    <div class="doc-header-username"><?= esc($fullname) ?></div>
                    <div class="doc-header-userrole">Administrator</div>
                </div>
                <div class="doc-header-dropdown">
                    <i class="fas fa-chevron-down"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Completely self-contained header styles */
.doc-header-wrapper {
    margin-bottom: 80px; /* Pushes content down */
}

.doc-header {
    background: #ffffff;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    height: 80px;
    position: fixed;
    top: 0;
    left: 250px; /* Matches sidebar width */
    right: 0;
    z-index: 100;
    transition: all 0.3s ease;
}

.doc-header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    padding: 0 30px;
    max-width: calc(100% - 250px);
    margin: 0 auto;
}

.doc-header-title h1 {
    font-size: 1.5rem;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
    line-height: 1.2;
}

.doc-header-title p {
    font-size: 0.875rem;
    color: #7f8c8d;
    margin: 4px 0 0 0;
}

.doc-header-user-profile {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 12px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.doc-header-user-profile:hover {
    background-color: #f5f5f5;
}

.doc-header-avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #3498db, #2ecc71);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
}

.doc-header-user-details {
    display: flex;
    flex-direction: column;
}

.doc-header-username {
    font-weight: 500;
    color: #2c3e50;
    font-size: 0.95rem;
}

.doc-header-userrole {
    font-size: 0.75rem;
    color: #95a5a6;
}

.doc-header-dropdown {
    color: #95a5a6;
    font-size: 0.75rem;
    transition: all 0.3s ease;
}

.doc-header-user-profile:hover .doc-header-dropdown {
    color: #2c3e50;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .doc-header {
        left: 80px; /* Matches collapsed sidebar */
        max-width: calc(100% - 80px);
    }
}

@media (max-width: 768px) {
    .doc-header {
        left: 0;
        max-width: 100%;
    }
    
    .doc-header-content {
        padding: 0 15px;
    }
    
    .doc-header-title h1 {
        font-size: 1.3rem;
    }
    
    .doc-header-title p {
        display: none;
    }
    
    .doc-header-userrole, 
    .doc-header-dropdown {
        display: none;
    }
    
    .doc-header-user-profile {
        padding: 5px;
    }
    
    .doc-header-avatar {
        width: 36px;
        height: 36px;
    }
}
</style>