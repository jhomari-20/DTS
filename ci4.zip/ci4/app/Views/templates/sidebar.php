<div class="sidebar">
    <div class="logo">
        <div class="logo-icon">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="logo-text">Doc<span>Track</span></div>
        <div class="menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </div>
    </div>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <div class="nav-menu">
        <div class="nav-item" onclick="navigateTo('user/index')">
            <div class="nav-icon"><i class="fas fa-home"></i></div>
            <div class="nav-text">Dashboard</div>
        </div>
        <div class="nav-item" onclick="navigateTo('user/document')">
            <div class="nav-icon"><i class="fas fa-folder"></i></div>
            <div class="nav-text">Documents</div>
        </div>
        <div class="nav-item" onclick="navigateTo('user/create')">
            <div class="nav-icon"><i class="fas fa-user-plus"></i></div>
            <div class="nav-text">Add Employee</div>
        </div>
        <div class="nav-item" onclick="navigateTo('')">
            <div class="nav-icon"><i class="fas fa-cog"></i></div>
            <div class="nav-text">Settings</div>
        </div>
        <div class="nav-item" onclick="logout()">
            <div class="nav-icon"><i class="fas fa-sign-out-alt"></i></div>
            <div class="nav-text">Log Out</div>
        </div>
    </div>
</div>

<style>
.sidebar {
    width: 280px;
    height: 100vh;
    background: linear-gradient(135deg, #2c3e50 0%, #1a2533 100%);
    position: fixed;
    left: 0;
    top: 0;
    padding: 25px 15px;
    box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    transition: all 0.3s ease;
    transform: translateX(0);
}

.logo {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    position: relative;
}

.logo-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(45deg, #3498db, #2ecc71);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
    color: white;
    font-size: 18px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    flex-shrink: 0;
}

.logo-text {
    color: white;
    font-size: 22px;
    font-weight: 700;
    letter-spacing: 1px;
    transition: all 0.3s ease;
    white-space: nowrap;
}

.logo-text span {
    color: #2ecc71;
    font-weight: 800;
}

.menu-toggle {
    display: none;
    position: absolute;
    right: 0;
    color: white;
    font-size: 20px;
    cursor: pointer;
    padding: 5px;
}

.nav-menu {
    display: flex;
    flex-direction: column;
    gap: 5px;
    overflow-y: auto;
    max-height: calc(100vh - 120px);
}

.nav-item {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #b3b3b3;
    white-space: nowrap;
}

.nav-item:hover {
    background: rgba(255, 255, 255, 0.05);
    color: white;
    transform: translateX(5px);
}

.nav-item.active {
    background: linear-gradient(90deg, rgba(46, 204, 113, 0.2) 0%, rgba(46, 204, 113, 0) 100%);
    color: #2ecc71;
    border-left: 3px solid #2ecc71;
}

.nav-icon {
    width: 30px;
    font-size: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.nav-text {
    font-size: 15px;
    font-weight: 500;
    transition: all 0.3s ease;
}

/* Logout item styling */
.nav-item:last-child {
    margin-top: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    padding-top: 20px;
}

.nav-item:last-child:hover {
    color: #e74c3c;
}

.nav-item:last-child:hover .nav-icon {
    color: #e74c3c;
}

/* Responsive styles */
@media (max-width: 992px) {
    .sidebar {
        transform: translateX(-90%);
        width: 80px;
    }
    
    .sidebar:hover {
        transform: translateX(0);
        width: 250px;
    }
    
    .sidebar:hover .logo-text,
    .sidebar:hover .nav-text {
        opacity: 1;
        display: inline;
    }
    
    .logo-text,
    .nav-text {
        opacity: 0;
        display: none;
        transition: all 0.3s ease;
    }
    
    .logo {
        justify-content: center;
        padding-bottom: 15px;
    }
    
    .logo-icon {
        margin-right: 0;
    }
    
    .nav-item {
        justify-content: center;
        padding: 12px 5px;
    }
    
    .nav-item:hover {
        transform: none;
    }
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
        width: 250px;
    }
    
    .sidebar.active {
        transform: translateX(0);
    }
    
    .menu-toggle {
        display: block;
    }
    
    .logo {
        justify-content: flex-start;
    }
    
    .logo-icon {
        margin-right: 12px;
    }
    
    .logo-text,
    .nav-text {
        opacity: 1;
        display: inline;
    }
    
    .nav-item {
        justify-content: flex-start;
        padding: 12px 15px;
    }
    
    .nav-item:hover {
        transform: translateX(5px);
    }
}
</style>

<script>
    function navigateTo(page) {
        window.location.href = "<?= base_url(); ?>" + page;
    }
    
    function logout() {
        window.location.href = "<?= base_url('logout'); ?>";
    }
    
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('active');
    }
    
    // Add active class to current page
    document.addEventListener('DOMContentLoaded', function() {
        const navItems = document.querySelectorAll('.nav-item');
        const currentPath = window.location.pathname.split('/').pop() || 'index';
        
        navItems.forEach(item => {
            const navText = item.querySelector('.nav-text').textContent.toLowerCase();
            if ((currentPath.includes('index') && navText === 'dashboard') ||
                (currentPath.includes('document') && navText === 'documents') ||
                (currentPath.includes('create') && navText === 'add employee') ||
                (currentPath.includes('settings') && navText === 'settings')) {
                item.classList.add('active');
            }
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.querySelector('.menu-toggle');
            if (window.innerWidth <= 768 && !sidebar.contains(event.target) && 
                event.target !== menuToggle && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('active');
            }
        });
    });
</script>