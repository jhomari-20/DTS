<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Include jQuery -->
</head>
<body>

    <!-- Include Sidebar -->
    <?= view('templates/sidebar'); ?>

    <!-- Main Content Area -->
    <div class="main-content" id="main-content">
        <?= view('pages/dashboard'); ?> <!-- Default page (Dashboard) -->
    </div>

    <script>
        function loadContent(page) {
            $.ajax({
                url: "<?= base_url('pages'); ?>/" + page,
                type: "GET",
                success: function(response) {
                    $("#main-content").html(response); // Load new content inside #main-content
                },
                error: function() {
                    alert("Error loading page.");
                }
            });
        }
    </script>

</body>
</html>
