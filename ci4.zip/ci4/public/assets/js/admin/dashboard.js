// DOM Elements
const video = document.getElementById('scanner-video');
const startBtn = document.getElementById('start-scanner');
const stopBtn = document.getElementById('stop-scanner');
const scanAnotherBtn = document.getElementById('scan-another');
const viewDocumentsBtn = document.getElementById('view-documents');
const resultsSection = document.getElementById('results-section');
const scannerSection = document.getElementById('scanner-section');
const documentInfo = document.getElementById('document-info');
const documentsTable = document.getElementById('documents-table');
const receiverSelect = document.getElementById('receiver-select');
const resultIcon = document.getElementById('result-icon');
const resultTitle = document.getElementById('result-title');
const resultMessage = document.getElementById('result-message');

// Document database (simulating backend data)
let documents = {
    '1': {
        id: '1',
        fullname: 'christian Varquez',
        doc_type: 'Payroll Records',
        date_received: '',
        received_by: '',
        status: 'Pending'
    },
    '2': {
        id: '2',
        fullname: 'Sarah Johnson',
        doc_type: 'NDA Agreement',
        date_received: '2023-06-15',
        received_by: 'Records Officer 1',
        status: 'Received'
    },
    '3': {
        id: '3',
        fullname: 'Michael Brown',
        doc_type: 'Offer Letter',
        date_received: '',
        received_by: '',
        status: 'Pending'
    }
};

// Start Scanner
startBtn.addEventListener('click', async () => {
    if (!receiverSelect.value) {
        alert('Please select a receiver before scanning');
        return;
    }
    
    try {
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: "environment" } 
        });
        video.srcObject = stream;
        video.play();
        
        scannerActive = true;
        startBtn.disabled = true;
        stopBtn.disabled = false;
        
        // Start scanning for QR codes
        interval = setInterval(scanQRCode, 100);
    } catch (err) {
        console.error("Error accessing camera:", err);
        alert("Could not access the camera. Please ensure you have granted camera permissions.");
    }
});

// Stop Scanner
stopBtn.addEventListener('click', () => {
    stopScanner();
});

// Scan Another Document
scanAnotherBtn.addEventListener('click', () => {
    resultsSection.style.display = 'none';
    scannerSection.style.display = 'block';
    startScanner();
});

// View Documents
viewDocumentsBtn.addEventListener('click', () => {
    resultsSection.style.display = 'none';
    scannerSection.style.display = 'none';
    document.querySelector('.documents-section').scrollIntoView({
        behavior: 'smooth'
    });
});

// QR Code Scanning Function
function scanQRCode() {
    if (!scannerActive) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height);
    
    if (code) {
        handleScannedData(code.data);
    }
}

// Handle Scanned Data
function handleScannedData(data) {
    // Stop scanner
    stopScanner();
    
    // Get current date and time
    const now = new Date();
    const receivedDate = now.toISOString().split('T')[0];
    const receivedTime = now.toTimeString().split(' ')[0];
    
    try {
        const docData = JSON.parse(data);
        const docId = docData.id || docData.documentId || '';
        
        // Check if document exists in our system
        if (documents[docId]) {
            // Update document status
            documents[docId].status = "Received";
            documents[docId].date_received = receivedDate;
            documents[docId].received_by = receiverSelect.value;
            
            // Update UI
            updateDocumentTable();
            
            // Show success message
            resultIcon.innerHTML = '<i class="fas fa-check-circle"></i>';
            resultIcon.style.color = 'var(--success)';
            resultTitle.textContent = 'Document Received!';
            resultMessage.textContent = 'The document has been successfully recorded in the system.';
            
            // Display document info
            documentInfo.innerHTML = `
                <div class="document-detail">
                    <label>Document ID:</label>
                    <span class="document-value">${docId}</span>
                </div>
                
                <div class="document-detail">
                    <label>Full Name:</label>
                    <span class="document-value">${docData.fullname || 'N/A'}</span>
                </div>
                
                <div class="document-detail">
                    <label>Document Type:</label>
                    <span class="document-value">${docData.doc_type || 'N/A'}</span>
                </div>
                
                <div class="document-detail">
                    <label>Received Date:</label>
                    <span class="document-value">${receivedDate} at ${receivedTime}</span>
                </div>
                
                <div class="document-detail">
                    <label>Received by:</label>
                    <span class="document-value">${receiverSelect.value}</span>
                </div>
                
                <p class="success-message">This document has been successfully recorded as received.</p>
            `;
        } else {
            // Document not found in system
            resultIcon.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
            resultIcon.style.color = 'var(--danger)';
            resultTitle.textContent = 'Document Not Found';
            resultMessage.textContent = 'This document is not registered in our system.';
            
            // Display scanned data in organized format
            documentInfo.innerHTML = `
                <h4>Scanned Document Details</h4>
                
                <div class="document-detail">
                    <label>Document ID:</label>
                    <span class="document-value">${docId || 'N/A'}</span>
                </div>
                
                <div class="document-detail">
                    <label>Full Name:</label>
                    <span class="document-value">${docData.fullname || 'N/A'}</span>
                </div>
                
                <div class="document-detail">
                    <label>Document Type:</label>
                    <span class="document-value">${docData.doc_type || 'N/A'}</span>
                </div>
                
                <p class="error-message">This document was not found in our system. Please verify the document ID or contact administration.</p>
            `;
        }
    } catch (e) {
        // Handle non-JSON QR codes
        resultIcon.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
        resultIcon.style.color = 'var(--warning)';
        resultTitle.textContent = 'Scan Result';
        resultMessage.textContent = 'The scanned QR code does not contain document information.';
        
        documentInfo.innerHTML = `
            <h4>Scanned Data</h4>
            <div class="document-detail">
                <label>Raw Data:</label>
                <span class="document-value">${data}</span>
            </div>
            <p class="error-message">This QR code does not contain valid document information.</p>
        `;
    }
    
    // Show results section
    resultsSection.style.display = 'block';
    scannerSection.style.display = 'none';
}

// Update Document Table
function updateDocumentTable() {
    let tableHTML = '';
    
    for (const [id, doc] of Object.entries(documents)) {
        tableHTML += `
            <tr>
                <td>#${id}</td>
                <td>${doc.doc_type}</td>
                <td>${doc.fullname}</td>
                <td>${doc.date_received || ''}</td>
                <td>${doc.received_by || ''}</td>
                <td><span class="status status-${doc.status.toLowerCase()}">${doc.status}</span></td>
            </tr>
        `;
    }
    
    documentsTable.innerHTML = tableHTML;
}

// Stop Scanner Function
function stopScanner() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
    if (interval) {
        clearInterval(interval);
    }
    scannerActive = false;
    startBtn.disabled = false;
    stopBtn.disabled = true;
}

// Initialize document table
updateDocumentTable();

// In a real application, you would have API calls to:
// 1. Load documents from server
// 2. Update document status on server when scanned
/*
async function updateDocumentStatus(documentId, receivedBy, receivedDate) {
    try {
        const response = await fetch('/api/documents/receive', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                document_id: documentId,
                received_by: receivedBy,
                received_date: receivedDate,
                status: 'Received'
            })
        });
        
        const data = await response.json();
        console.log('Server response:', data);
        return data;
    } catch (error) {
        console.error('Error updating document:', error);
        throw error;
    }
}
*/
