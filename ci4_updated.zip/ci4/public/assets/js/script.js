// QR Modal Functions
function openQRModal(docId, fullname, docType) {
    const qrData = JSON.stringify({
        id: docId,
        fullname: fullname,
        doc_type: docType
    });
    
    document.getElementById('documentIdDisplay').textContent = `Document ID: ${docId}`;
    document.getElementById('qrImage').src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(qrData);
    document.getElementById('qrModal').style.display = 'flex';
}

function closeQRModal() {
    document.getElementById('qrModal').style.display = 'none';
}
function printQR() {
    let qrImage = document.getElementById('qrImage');

    // Create a new window for printing
    let printWindow = window.open('', '_blank');

    // Write the QR image into the new window
    printWindow.document.write(`
        <html>
        <head>
            <title>Print QR Code</title>
            <style>
                body { 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    height: 100vh; 
                    margin: 0; 
                }
                img { 
                    max-width: 100%; 
                    height: auto; 
                }
            </style>
        </head>
        <body>
            <img src="${qrImage.src}" alt="QR Code">
        </body>
        </html>
    `);

    // Wait for the content to load and trigger the print dialog
    printWindow.document.close();
    printWindow.focus();
    printWindow.onload = function() {
        printWindow.print();
        printWindow.close();
    };
}

// function downloadQR() {
//     const qrImage = document.getElementById('qrImage');
//     const docId = document.getElementById('documentIdDisplay').textContent.split(': ')[1];
    
//     const link = document.createElement('a');
//     link.href = qrImage.src;
//     link.download = `QRCode-${docId}.png`;
//     document.body.appendChild(link);
//     link.click();
//     document.body.removeChild(link);
// }

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('qrModal');
    if (event.target == modal) {
        closeQRModal();
    }
}
function deleteDocument(id) {
    if (!confirm("Are you sure you want to delete this document?")) return;

    fetch(`/user/documents/delete/${id}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Document deleted successfully!");
                location.reload(); // Refresh the page to update the table
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch(error => console.error("Delete failed:", error));
}

