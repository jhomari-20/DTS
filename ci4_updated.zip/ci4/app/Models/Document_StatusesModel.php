<?php
namespace App\Models;
namespace App\Models;

use CodeIgniter\Model;

class Document_StatusesModel extends Model
{
    protected $table = 'documents_statuses'; // Correct table name
    protected $primaryKey = 'id';
    protected $allowedFields = ['document_id', 'received_by', 'status', 'remarks', 'date'];

    public function getRecentDocumentsByDepartment($department)
    {
        return $this->select('ds.id, d.doc_type, d.fullname, ds.date, ds.status')
            ->from('documents_statuses ds')
            ->join('documents d', 'd.id = ds.document_id')
            ->where('ds.received_by', $department)  // Filter by department
            ->orderBy('ds.date', 'DESC')  // Get the most recent status first
            ->groupBy('ds.document_id')  // Ensure we get the latest status per document
            ->limit(10)  // Limit to 10 recent documents
            ->findAll();
    }    
}

