<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Main Routes
$routes->get('/', 'LoginController::index'); // Loads home page
$routes->get('login', 'LoginController::index');
$routes->post('login/authenticate', 'LoginController::authenticate');
$routes->get('logout', 'LoginController::logout');
$routes->post('home/store', 'HomeController::store'); // Post route for storing

// User/Employee Routes
$routes->group('user', function($routes) {
    $routes->get('index', 'HomeController::index'); // User dashboard
    $routes->get('create', 'HomeController::create'); // Create user
    $routes->get('document', 'DocumentController::index'); // User documents
    $routes->get('edit', 'HomeController::edit'); // Edit user profile
    $routes->post('documents/delete/(:num)', 'DocumentController::delete/$1'); // Delete document
    $routes->get('getDocumentHistory/(:num)', 'HomeController::getDocumentHistory/$1');
});

$routes->group('admin', function($routes) { 
    $routes->post('store', 'AdminController::store'); // Store admin data
    $routes->get('dashboard', 'AdminController::dashboard');
    $routes->post('authenticate', 'AdloginController::authenticate');
    $routes->post('saveDocument', 'AdminController::saveDocument');
    $routes->post('logout', 'AdloginController::logout');
    $routes->get('index', 'AdloginController::index'); // Admin dashboard
    $routes->get('recent', 'AdminController::recent');
});

    