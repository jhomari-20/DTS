<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet">
 
</head>
<body>
    <?= view('templates/sidebar'); ?>
    
    <!-- Main Content Area -->
    <div class="main-content">
    
    <?= view('templates/header'); ?>
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-title">Total Documents</div>
                    <div class="stat-icon documents">
                        <i class="fas fa-file-alt"></i>
                    </div>
                </div>
                <div class="stat-value"><?= esc($totalDocuments) ?></div>
                    <div class="stat-change <?= $percentChangeDocuments >= 0 ? 'positive' : 'negative' ?>">
                        <i class="fas fa-arrow-<?= $percentChangeDocuments >= 0 ? 'up' : 'down' ?>"></i>
                        <?= round(abs($percentChangeDocuments), 2) ?>% from last month
                    </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                <div class="stat-title">Total Approved</div>
                    <div class="stat-icon shared">
                        <i class="fas fa-share-alt"></i>
                    </div>
                </div>
                <div class="stat-value"><?= esc($totalApproved) ?></div>
                <div class="stat-change <?= $percentChangeApproved >= 0 ? 'positive' : 'negative' ?>">
                    <i class="fas fa-arrow-<?= $percentChangeApproved >= 0 ? 'up' : 'down' ?>"></i>
                    <?= round(abs($percentChangeApproved), 2) ?>% from last month
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-title">Pending Approvals</div>
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
                <div class="stat-value"><?= esc($totalPending) ?></div>
                <div class="stat-change <?= $percentChangePending >= 0 ? 'positive' : 'negative' ?>">
                    <i class="fas fa-arrow-<?= $percentChangePending >= 0 ? 'up' : 'down' ?>"></i>
                    <?= round(abs($percentChangePending), 2) ?>% from last month
                </div>
            </div>
        </div>
        
        <!-- Main Content Grid -->
        <div class="content-grid">
            <!-- Recent Documents -->
            <div class="recent-documents">
                <div class="section-header">
                    <div class="section-title">Recent Documents</div>
                    <div class="view-all">View All</div>
                </div>
                
                <table class="documents-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Last Modified</th>
                            <th>Size</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="document-info">
                                    <div class="document-icon">
                                        <i class="fas fa-file-pdf"></i>
                                    </div>
                                    <div>
                                        <div class="document-name">Q3 Financial Report</div>
                                        <div class="document-meta">Finance • PDF</div>
                                    </div>
                                </div>
                            </td>
                            <td>2 hours ago</td>
                            <td>4.2 MB</td>
                            <td><span class="document-status status-approved">Approved</span></td>
                        </tr>
                        <tr>
                            <td>
                                <div class="document-info">
                                    <div class="document-icon">
                                        <i class="fas fa-file-word"></i>
                                    </div>
                                    <div>
                                        <div class="document-name">Product Requirements</div>
                                        <div class="document-meta">Product • DOCX</div>
                                    </div>
                                </div>
                            </td>
                            <td>Yesterday</td>
                            <td>1.8 MB</td>
                            <td><span class="document-status status-pending">Pending</span></td>
                        </tr>
                        <tr>
                            <td>
                                <div class="document-info">
                                    <div class="document-icon">
                                        <i class="fas fa-file-excel"></i>
                                    </div>
                                    <div>
                                        <div class="document-name">Sales Data 2023</div>
                                        <div class="document-meta">Sales • XLSX</div>
                                    </div>
                                </div>
                            </td>
                            <td>2 days ago</td>
                            <td>6.7 MB</td>
                            <td><span class="document-status status-approved">Approved</span></td>
                        </tr>
                        <tr>
                            <td>
                                <div class="document-info">
                                    <div class="document-icon">
                                        <i class="fas fa-file-powerpoint"></i>
                                    </div>
                                    <div>
                                        <div class="document-name">Marketing Strategy</div>
                                        <div class="document-meta">Marketing • PPTX</div>
                                    </div>
                                </div>
                            </td>
                            <td>3 days ago</td>
                            <td>8.1 MB</td>
                            <td><span class="document-status status-review">In Review</span></td>
                        </tr>
                        <tr>
                            <td>
                                <div class="document-info">
                                    <div class="document-icon">
                                        <i class="fas fa-file-image"></i>
                                    </div>
                                    <div>
                                        <div class="document-name">Brand Assets</div>
                                        <div class="document-meta">Design • ZIP</div>
                                    </div>
                                </div>
                            </td>
                            <td>1 week ago</td>
                            <td>24.5 MB</td>
                            <td><span class="document-status status-approved">Approved</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- Activity Feed -->
            <div class="activity-feed">
                <div class="section-header">
                    <div class="section-title">Recent Activity</div>
                    <div class="view-all">View All</div>
                </div>
                
                <div class="activity-item">
                    <div class="activity-avatar">SM</div>
                    <div class="activity-content">
                        <div class="activity-user">Sarah Miller</div>
                        <div class="activity-text">Uploaded a new document "Q3 Financial Report" to the Finance folder</div>
                        <div class="activity-time">
                            <i class="far fa-clock"></i> 15 minutes ago
                        </div>
                    </div>
                </div>
                
                <div class="activity-item">
                    <div class="activity-avatar">DJ</div>
                    <div class="activity-content">
                        <div class="activity-user">David Johnson</div>
                        <div class="activity-text">Approved the "Product Roadmap" document you shared</div>
                        <div class="activity-time">
                            <i class="far fa-clock"></i> 2 hours ago
                        </div>
                    </div>
                </div>
                
                <div class="activity-item">
                    <div class="activity-avatar">TP</div>
                    <div class="activity-content">
                        <div class="activity-user">Team Project</div>
                        <div class="activity-text">You were mentioned in a comment on "Marketing Strategy"</div>
                        <div class="activity-time">
                            <i class="far fa-clock"></i> 5 hours ago
                        </div>
                    </div>
                </div>
                
                <div class="activity-item">
                    <div class="activity-avatar">AD</div>
                    <div class="activity-content">
                        <div class="activity-user">You</div>
                        <div class="activity-text">Shared "Sales Presentation" with 3 team members</div>
                        <div class="activity-time">
                            <i class="far fa-clock"></i> Yesterday
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Storage Usage -->
        <div class="storage-usage">
            <div class="section-header">
                <div class="section-title">Storage Usage</div>
            </div>
            
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
                
                <div class="storage-details">
                    <div>12.4 GB used</div>
                    <div>7.6 GB available</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>