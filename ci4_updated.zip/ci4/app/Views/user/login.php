<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_hash(); ?>"> <!-- CSRF Token for AJAX if needed -->
    <title>DocTrack Pro | Secure Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/login.css">
</head>
<body>
    
    <div class="login-wrapper">
        <div class="doc-corner doc-top-left"><i class="fas fa-file-signature"></i></div>
        <div class="doc-corner doc-top-right"><i class="fas fa-file-invoice"></i></div>
        <div class="doc-corner doc-bottom-left"><i class="fas fa-file-export"></i></div>
        <div class="doc-corner doc-bottom-right"><i class="fas fa-file-import"></i></div>
        
        <div class="login-card">
            <div class="brand-header">
                <div >
                <img src="<?= base_url('assets/image/logo.png') ?>" alt="Logo" style="width: 100px; height: auto;">
                </div>
                <h1>Document Tracking<span> System</span></h1>
                <p>DepEd Southern Leyte Division</p>
            </div>

            <!-- Modify the form action to point to your backend login route -->
            <form class="auth-form" action="<?= site_url('login/authenticate') ?>" method="post">
            <?= csrf_field() ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <p><?= esc($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="form-field">
                <label for="username">Username</label>
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" placeholder="Enter your username" value="<?= old('username') ?>" required>
                </div>
            </div>

            <div class="form-field">
                <label for="password">Password</label>
                <div class="input-group">
                    <i class="fas fa-key"></i>
                    <i class="fas fa-eye" id="toggle-password"></i> <!-- Eye icon for toggling -->
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
            </div>

            <div class="form-options">
                <label class="remember-me">
                    <input type="checkbox" name="remember">
                    <span>Keep me signed in</span>
                </label>
                <a href="/forgot-password" class="forgot-pw">Forgot password?</a>
            </div>

            <button type="submit" class="auth-btn">
                <span>Sign In</span>
                <i class="fas fa-arrow-right"></i>
            </button>
        </form>
            
            <div class="auth-footer">
                <p>New to DocTrackPro? <a href="/register">Create account</a></p>
                <div class="auth-divider">
                    <span>or continue with</span>
                </div>
                <div class="social-auth">
                    <a href="#" class="social-btn google">
                        <i class="fab fa-google"></i>
                    </a>
                    <a href="#" class="social-btn microsoft">
                        <i class="fab fa-microsoft"></i>
                    </a>
                    <a href="#" class="social-btn apple">
                        <i class="fab fa-apple"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="floating-docs">
            <div class="doc-file"><i class="fas fa-file-pdf"></i></div>
            <div class="doc-file"><i class="fas fa-file-word"></i></div>
            <div class="doc-file"><i class="fas fa-file-excel"></i></div>
            <div class="doc-file"><i class="fas fa-file-powerpoint"></i></div>
        </div>
    </div>
    <script>
    document.getElementById('toggle-password').addEventListener('click', function () {
        var passwordField = document.getElementById('password');
        var type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);

        // Toggle the eye icon
        this.classList.toggle('fa-eye-slash');
    });
</script>
</body>
</html>
