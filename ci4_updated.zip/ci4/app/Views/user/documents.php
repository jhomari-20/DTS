<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack Pro | Premium Document Tracking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/documents.css') ?>">
    <style>
    /* Style for the filter button */
    .filter-btn {
        position: relative;
        width: 250px;
        margin: 0 auto;
    }

    /* Style for the select dropdown */
    #filterDocType {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        border-radius: 8px;
        border: 1px solid #ccc;
        background-color: #f9f9f9;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    /* Hover effect for the select dropdown */
    #filterDocType:hover {
        border-color: #007bff;
        background-color: #e9f1ff;
    }

    /* Focus effect for the select dropdown */
    #filterDocType:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }

    /* Style for the option elements */
    #filterDocType option {
        padding: 10px;
        font-size: 10px;
    }
    .modal-actions .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    border: none;
    transition: all 0.3s ease;
    text-decoration: none;
}

/* Primary Button (Print) */
.modal-actions .btn-primary {
    background-color: #007bff;
    color: white;
    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.2);
}

.modal-actions .btn-primary:hover {
    background-color: #0056b3;
    box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);
}

/* Secondary Button (Close) */
.modal-actions .btn-secondary {
    background-color: #e4e6eb;
    color: #333;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.modal-actions .btn-secondary:hover {
    background-color: #d4d6da;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}
/* Premium Document Tracking History Modal */
#historyModal {
    display: none;
    position: fixed;
    z-index: 1050;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    animation: fadeIn 0.3s ease;
}

#historyModal .modal-content {
    background: white;
    margin: 5% auto;
    padding: 32px;
    border-radius: 20px;
    width: 90%;
    max-width: 680px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
}

#historyModal .modal-content::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 6px;
    height: 100%;
    background: linear-gradient(to bottom, #3b82f6, #1d4ed8);
}

#historyModal h3 {
    margin: 0 0 24px 0;
    font-size: 1.8rem;
    color: #1e293b;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
}

#historyModal h3 i {
    color: #3b82f6;
    font-size: 1.6rem;
}

#historyModal .close {
    position: absolute;
    top: 28px;
    right: 28px;
    font-size: 1.8rem;
    color: #64748b;
    transition: all 0.3s ease;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

#historyModal .close:hover {
    color: #ef4444;
    background: rgba(239, 68, 68, 0.1);
    transform: rotate(90deg);
}

/* Timeline Style History Cards */
#historyContent {
    max-height: 60vh;
    overflow-y: auto;
    padding-right: 8px;
}

.timeline-item {
    position: relative;
    padding: 24px;
    margin-bottom: 20px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    animation: fadeInUp 0.4s ease;
}

.timeline-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
    border-color: rgba(59, 130, 246, 0.2);
}

.timeline-item::before {
    content: '';
    position: absolute;
    left: -1px;
    top: 24px;
    height: calc(100% - 48px);
    width: 2px;
    background: #e2e8f0;
}

.timeline-item:last-child::before {
    display: none;
}

.timeline-dot {
    position: absolute;
    left: -8px;
    top: 32px;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: #3b82f6;
    border: 3px solid white;
    box-shadow: 0 0 0 2px #3b82f6;
    z-index: 2;
}

.timeline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.timeline-office {
    font-weight: 700;
    color: #1e293b;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 8px;
}

.timeline-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-received { background: #dbeafe; color: #1d4ed8; }
.status-processed { background: #ffedd5; color: #9a3412; }
.status-completed { background: #dcfce7; color: #166534; }

.timeline-date {
    font-size: 0.85rem;
    color: #64748b;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.timeline-date i {
    font-size: 0.9rem;
}

.timeline-remarks {
    background: #f8fafc;
    padding: 12px 16px;
    border-radius: 12px;
    margin-top: 12px;
    border-left: 3px solid #e2e8f0;
    color: #475569;
    font-size: 0.95rem;
}

.empty-remarks {
    color: #94a3b8;
    font-style: italic;
    font-size: 0.9rem;
}

/* Empty State */
.empty-history {
    text-align: center;
    padding: 40px 20px;
    color: #64748b;
}

.empty-history i {
    font-size: 3rem;
    color: #cbd5e1;
    margin-bottom: 16px;
}

.empty-history p {
    font-size: 1.1rem;
    margin-bottom: 8px;
}

.empty-history small {
    font-size: 0.9rem;
    color: #94a3b8;
}

/* Animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Scrollbar Styling */
#historyContent::-webkit-scrollbar {
    width: 6px;
}

#historyContent::-webkit-scrollbar-track {
    background: rgba(241, 245, 249, 0.5);
}

#historyContent::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
}

/* Responsive Design */
@media (max-width: 768px) {
    #historyModal .modal-content {
        padding: 24px;
        margin: 10% auto;
    }
    
    .timeline-item {
        padding: 20px;
    }
}


</style>
</head>
<body>
    <?= view('templates/sidebar'); ?>
    
    <div class="main-content">
    <?= view('templates/header'); ?>
        <!-- Dashboard Section -->
        <section class="container">
            <div class="dashboard">
                <div class="dashboard-header">
                    <h2 class="dashboard-title">Document Tracking</h2>
                    <div class="search-filter">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search documents..." onkeyup="filterTable()">
                        </div>
                        <div class="filter-btn">
                            <select id="filterDocType" onchange="filterTable()">
                                <option value="">All Document Types</option>
                                <option value="Performance Review">Performance Review</option>
                                <option value="Employment Contract">Employment Contract	</option>
                                <option value="Training Materials">Training Materials</option>
                                <option value="Payroll Records">Payroll Records</option>
                            
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Document Table -->
            <div class="table-container">
                <table class="document-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Document Type</th>
                                <th>Full Name</th>
                                <th>Date</th>
                                <th>Office Received</th>
                                <!-- <th>Status</th> -->
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $counter= 1; ?>
                            <?php if (!empty($documents) && is_array($documents)): ?>
                                <?php foreach ($documents as $document): ?>
                                    <tr>
                                        <td><?= $counter++ ?></td>
                                        <td><?= esc($document['doc_type']) ?></td>
                                        <td><?= esc($document['fullname']) ?></td>
                                        <td><?= esc($document['date']) ?></td>
                                        <td><?= esc($document['received_by'] ?? 'Pending') ?></td>
                                        <!-- <td>
                                            <?php 
                                                $statusClass = '';
                                                switch (strtolower($document['status'])) {
                                                    case 'pending':
                                                        $statusClass = 'status-pending';
                                                        break;
                                                    case 'approved':
                                                        $statusClass = 'status-approved';
                                                        break;
                                                    case 'rejected':
                                                        $statusClass = 'status-rejected';
                                                        break;
                                                }
                                            ?>
                                            <span class="status <?= $statusClass ?>">
                                                <?= esc($document['status']) ?>
                                            </span>
                                        </td> -->
                                        <td>
                                            <button class="action-btn" onclick="openQRModal('<?= esc($document['id']) ?>', '<?= esc($document['fullname']) ?>', '<?= esc($document['doc_type']) ?>')">
                                                <i class="fas fa-qrcode"></i>
                                            </button>
                                            <button class="action-btn" onclick="viewDocumentHistory(<?= $document['id']; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>

                                            <button onclick="deleteDocument(<?= $document['id']; ?>)" class="action-btn">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7">No documents found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>     
        </section> 
        <!-- QR Code Modal -->
    <div id="qrModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeQRModal()">&times;</span>
            <div class="modal-header">
                <h3>Document QR Code</h3>
                <p id="documentIdDisplay"></p>
            </div>
            <div class="qr-code">
                <img id="qrImage" src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=DOC-1001" alt="QR Code">
            </div>
            <div class="modal-actions">
                <button class="btn btn-primary" onclick="printQR()">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-secondary" onclick="closeQRModal()">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    </div>

    <!-- History Modal (moved out of QR modal) -->
    <div id="historyModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeHistoryModal()">&times;</span>
            <h3>Document History</h3>
            <div id="historyContent">
                <p>Loading history...</p>
            </div>
        </div>
    </div>

    <script src="<?= base_url('assets/js/script.js'); ?>"></script>

    
   <script>
        function filterTable() {
                // Get the value of the search input field
                let searchInput = document.getElementById('searchInput').value.toLowerCase();
                
                // Get the selected document type filter
                let filterDocType = document.getElementById('filterDocType').value.toLowerCase();

                // Get the table and its rows
                let table = document.querySelector('.document-table');
                let rows = table.querySelectorAll('tbody tr');

                // Loop through all table rows and hide those that don't match the search term and filter
                rows.forEach(row => {
                    let cells = row.getElementsByTagName('td');
                    let matchSearch = false;
                    let matchType = false;

                    // Loop through each cell in the row to check for search term match
                    for (let i = 0; i < cells.length; i++) {
                        if (cells[i].textContent.toLowerCase().includes(searchInput)) {
                            matchSearch = true;
                        }
                    }

                    // Check if the document type column (second column) matches the selected filter
                    let documentTypeCell = row.cells[1].textContent.toLowerCase();
                    if (filterDocType === '' || documentTypeCell.includes(filterDocType)) {
                        matchType = true;
                    }

                    // Show or hide the row based on whether both search and filter conditions are met
                    if (matchSearch && matchType) {
                        row.style.display = ''; // Show the row
                    } else {
                        row.style.display = 'none'; // Hide the row
                    }
                });
            }
            function viewDocumentHistory(documentId) {
                const modal = document.getElementById('historyModal');
                const content = document.getElementById('historyContent');

                modal.style.display = 'block';
                content.innerHTML = `
                    <div class="empty-history">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading document history</p>
                    </div>
                `;

                fetch(`getDocumentHistory/${documentId}`)
    .then(response => response.json())
    .then(data => {
        if (data.length === 0) {
            content.innerHTML = `
                <div class="empty-history">
                    <i class="far fa-file-alt"></i>
                    <p>No tracking history found</p>
                    <small>This document hasn't been processed yet</small>
                </div>
            `;
            return;
        }
        // Sort by date in ASCENDING order (oldest first)
        data.sort((b, a) => new Date(a.date) - new Date(b.date));
        
        let html = '';
        data.forEach((entry, index) => {
            const date = new Date(entry.date);
            html += `
                <div class="timeline-item" style="animation-delay: ${index * 0.05}s">
                    <div class="timeline-dot"></div>
                    <div class="timeline-header">
                        <div class="timeline-office">
                            <i class="fas fa-building"></i>
                            ${entry.received_by || 'System'}
                        </div>
                        <span class="timeline-status status-${entry.status.toLowerCase()}">
                            ${entry.status}
                        </span>
                    </div>
                    <div class="timeline-date">
                        <i class="far fa-calendar-alt"></i>
                        ${date.toLocaleDateString('en-US', {month: 'long', day: '2-digit', year: 'numeric', timeZone: 'Asia/Manila'}).replace(',', '/')} at 
                        ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', timeZone: 'Asia/Manila'})}
                    </div>
                    <div class="timeline-remarks">
                        ${entry.remarks || '<span class="empty-remarks">No remarks provided</span>'}
                    </div>
                </div>
            `;
        });

        content.innerHTML = html;
    })
    .catch(err => {
        content.innerHTML = `
            <div class="empty-history">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading history</p>
                <small>Please try again later</small>
            </div>
        `;
        console.error(err);
    });

            }
            function closeHistoryModal() {
                document.getElementById('historyModal').style.display = 'none';
            }


    </script>
</body>
</html>
