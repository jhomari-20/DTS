<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack - Employee Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <style>
        /* Mobile Menu Button */

      
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <?= view('templates/sidebar')?>
            <!-- Other nav items -->
        </div>
    </div>
    
    <!-- Main Content Area - Employee Management -->
    <div class="main-content">
    <?= view('templates/header')?>
        <!-- Employee Form -->
        <div class="employee-form">
            <h2>Add New Employee Request</h2>
            <form id="employeeRequestForm" action="<?= base_url('home/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="form-row">
                <div class="form-group">
                    <label for="fullName">Full Name</label>
                    <input type="text" id="fullName" name="fullname" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="docname">Document Name</label> 
                    <input type="text" id="docname" name="employee_id" class="form-control" required>
                </div>
            </div>
            
            <div class="form-row">
               <div class="form-group">
                    <label for="units">Functional Units</label> 
                    <select id="units" name="doc_type" class="form-control" required>
                        <option value="">Select Units</option>
                        <option value="Employment Contract">Employment Contract</option>
                        <option value="Payroll Records">Payroll Records</option>
                        <option value="Performance Review">Performance Review</option>
                        <option value="Training Materials">Training Materials</option>
                        <option value="Other">Other</option>
                        <option value="SDS Office">SDS Office</option>
                        <option value="HR">HR</option>
                        <option value="Cashier">Cashier</option>
                        <option value="Budget">Budget</option>
                        <option value="Accounting">Accounting</option>
                        <option value="Payroll">Payroll</option>
                        <option value="Admin">Admin</option>
                        <option value="Supply">Supply</option>
                        <option value="Legal">Legal</option>
                        <option value="LR">LR</option>
                        <option value="Library">Library</option>
                        <option value="Medical">Medical</option>
                        <option value="CID">CID</option>
                        <option value="Planning">Planning</option>
                        <option value="SGOD Office">SGOD Office</option>
                        <option value="Sports">Sports</option>
                        <option value="DRRM">DRRM</option>
                        <option value="ASDS">ASDS</option>
                        <option value="COA">COA</option>
                        <option value="Accounting 3rd floor">Accounting 3rd floor</option>
                        <option value="Engineering">Engineering</option>
                        <option value="ICT">ICT</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="requestDate">Request Date</label>
                    <input type="date" id="requestDate" name="date" class="form-control" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="purpose">Comments/Remarks</label>
                <textarea id="purpose" name="purpose" class="form-control" rows="3" ></textarea>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-submit">
                    <i class="fas fa-qrcode"></i> Generate Request
                </button>
            </div>
        </form>
            
     
            
          
    </div>

    <!-- Print Modal -->
    <div id="printModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Print Document Access</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body" id="printModalContent">
                <!-- Content will be inserted here -->
            </div>
            <div class="modal-footer">
                <button id="printBtn" class="btn-print">
                    <i class="fas fa-print"></i> Print
                </button>
            </div>
        </div>
    </div>
    <script src="<?= base_url('assets/js/script.js'); ?>"></script>
</body>
</html>