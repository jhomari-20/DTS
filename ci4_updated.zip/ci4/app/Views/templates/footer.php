<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-section">
            <h4>Document Tracking System</h4>
            <p>A premium solution for managing and tracking document workflows across departments.</p>
        </div>

        <div class="footer-section">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="<?= base_url() ?>">Dashboard</a></li>
                <li><a href="<?= base_url('documents') ?>">Documents</a></li>
                <li><a href="<?= base_url('about') ?>">About</a></li>
                <li><a href="<?= base_url('contact') ?>">Contact</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Support</h4>
            <ul>
                <li><a href="<?= base_url('help') ?>">Help Center</a></li>
                <li><a href="<?= base_url('privacy') ?>">Privacy Policy</a></li>
                <li><a href="<?= base_url('terms') ?>">Terms of Service</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Contact Us</h4>
            <p><i class="fas fa-envelope"></i> support@doctrack.com</p>
            <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> Document Tracking System. All rights reserved.</p>
        <p>v1.0.0</p>
    </div>
</footer>

<!-- Font Awesome for icons (add in header) -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<!-- Include your main JS file -->
<script src="<?= base_url('assets/js/script.js') ?>"></script>

</body>
</html>