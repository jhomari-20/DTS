<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocTrack Pro | Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/@phosphor-icons/web@2.0.3/src/regular/style.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --dark: #212529;
            --light: #f8f9fa;
            --sidebar-width: 280px;
            --header-height: 70px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f5f7fb;
            color: #333;
            line-height: 1.6;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .admin-sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: white;
            position: fixed;
            height: 100vh;
            transition: var(--transition);
            z-index: 100;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 1.5rem 1.5rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-brand img {
            width: 36px;
            margin-right: 12px;
        }

        .sidebar-brand span {
            font-size: 1.25rem;
            font-weight: 600;
        }

        .sidebar-nav {
            padding: 1.5rem;
            list-style: none;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
            position: relative;
        }

        .sidebar-nav li a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
        }

        .sidebar-nav li a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .sidebar-nav li.active a {
            background: var(--primary);
            color: white;
        }

        .sidebar-nav li a i {
            font-size: 1.25rem;
            margin-right: 12px;
            width: 24px;
            text-align: center;
        }

        .sidebar-nav li a .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 0.25rem 0.5rem;
            border-radius: 50px;
        }

        .nav-section {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 1.5rem 0 0.5rem;
            padding: 0 1rem;
        }

        /* Main Content Styles */
        .admin-main {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
            height: var(--header-height);
            background: white;
            box-shadow: 0 1px 15px rgba(0, 0, 0, 0.04);
            position: sticky;
            top: 0;
            z-index: 90;
        }

        .header-left {
            display: flex;
            align-items: center;
        }

        .header-left h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-left: 1rem;
        }

        .sidebar-toggle {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--dark);
            cursor: pointer;
            display: none;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }

        .search-box input {
            padding: 0.5rem 1rem 0.5rem 2.5rem;
            border: 1px solid #e9ecef;
            border-radius: 50px;
            width: 250px;
            transition: var(--transition);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .profile-dropdown {
            display: flex;
            align-items: center;
            position: relative;
            cursor: pointer;
        }

        .profile-dropdown img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.75rem;
        }

        .profile-dropdown span {
            font-weight: 500;
        }

        .profile-dropdown i {
            margin-left: 0.5rem;
            font-size: 0.8rem;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 0;
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 100;
        }

        .profile-dropdown:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            top: calc(100% + 10px);
        }

        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 0.5rem 1rem;
            color: var(--dark);
            text-decoration: none;
            transition: var(--transition);
        }

        .dropdown-menu a:hover {
            background: #f8f9fa;
            color: var(--primary);
        }

        .dropdown-menu a i {
            margin-right: 0.75rem;
            font-size: 1rem;
        }

        .notifications {
            position: relative;
            font-size: 1.25rem;
            color: var(--dark);
            cursor: pointer;
        }

        .notifications .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            font-size: 0.6rem;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .admin-content {
            padding: 2rem;
            min-height: calc(100vh - var(--header-height));
        }

        /* Document Management Styles */
        .document-management {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
        }

        .document-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .document-header h2 {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .document-actions {
            display: flex;
            gap: 1rem;
        }

        .document-search {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .document-search input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: 1px solid #e9ecef;
            border-radius: 8px;
        }

        .document-search button {
            padding: 0.75rem 1.5rem;
        }

        .document-filters {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .document-filters select {
            padding: 0.75rem 1rem;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            min-width: 180px;
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th {
            text-align: left;
            padding: 0.75rem 1rem;
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }

        .table td {
            padding: 0.75rem 1rem;
            border-top: 1px solid #f1f3f5;
        }

        .table tr:hover td {
            background: #f8f9fa;
        }

        .badge {
            display: inline-block;
            padding: 0.35em 0.65em;
            font-size: 0.75em;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }

        .bg-primary {
            background-color: var(--primary);
            color: white;
        }

        .bg-success {
            background-color: #28a745;
            color: white;
        }

        .bg-warning {
            background-color: var(--warning);
            color: white;
        }

        .bg-danger {
            background-color: var(--danger);
            color: white;
        }

        .bg-secondary {
            background-color: #6c757d;
            color: white;
        }

        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            border: none;
        }

        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .btn-success {
            background: #28a745;
            color: white;
        }

        .btn-success:hover {
            background: #218838;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background: #e0a800;
        }

        .btn-info {
            background: var(--info);
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        .btn-outline-primary {
            background: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }

        .btn-outline-primary:hover {
            background: var(--primary);
            color: white;
        }

        .btn-icon {
            width: 32px;
            height: 32px;
            padding: 0;
            border-radius: 50%;
        }

        /* Pagination */
        .pagination {
            display: flex;
            gap: 0.5rem;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }
            
            .admin-main {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: block;
            }
            
            .sidebar-show .admin-sidebar {
                transform: translateX(0);
            }
            
            .sidebar-show .admin-main {
                margin-left: var(--sidebar-width);
            }
            
            .search-box input {
                width: 180px;
            }
        }

        @media (max-width: 768px) {
            .admin-header {
                padding: 0 1rem;
            }
            
            .header-left h1 {
                display: none;
            }
            
            .search-box {
                display: none;
            }
            
            .admin-content {
                padding: 1rem;
            }

            .document-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }

            .document-actions {
                width: 100%;
                justify-content: flex-end;
            }

            .document-search {
                flex-direction: column;
            }

            .document-filters {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <img src="/assets/images/logo-white.png" alt="Logo">
                <span>DocTrack Pro</span>
            </div>
            <ul class="sidebar-nav">
                <li>
                    <a href="/admin/dashboard">
                        <i class="ph ph-gauge"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="active">
                    <a href="/admin/documents">
                        <i class="ph ph-file-text"></i>
                        <span>Documents</span>
                        <span class="badge">24</span>
                    </a>
                </li>
                <li class="nav-section">
                    <span>User Management</span>
                </li>
                <li>
                    <a href="/admin/ao2-accounts">
                        <i class="ph ph-user-circle-gear"></i>
                        <span>AO2 Accounts</span>
                    </a>
                </li>
                <li>
                    <a href="/admin/office-accounts">
                        <i class="ph ph-buildings"></i>
                        <span>Office Accounts</span>
                    </a>
                </li>
                <li>
                    <a href="/admin/activity-logs">
                        <i class="ph ph-list-checks"></i>
                        <span>Activity Logs</span>
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content Area -->
        <main class="admin-main">
            <header class="admin-header">
                <div class="header-left">
                    <button class="sidebar-toggle">
                        <i class="ph ph-list"></i>
                    </button>
                    <h1>Document Tracking</h1>
                </div>
                <div class="header-right">
                    <div class="search-box">
                        <i class="ph ph-magnifying-glass"></i>
                        <input type="text" placeholder="Search...">
                    </div>
                    <div class="admin-profile">
                        <div class="profile-dropdown">
                            <img src="/assets/images/avatars/admin.jpg" alt="Admin">
                            <span>Admin User</span>
                            <i class="ph ph-caret-down"></i>
                            <div class="dropdown-menu">
                                <a href="#"><i class="ph ph-user"></i> Profile</a>
                                <a href="#"><i class="ph ph-gear"></i> Settings</a>
                                <a href="/logout"><i class="ph ph-sign-out"></i> Logout</a>
                            </div>
                        </div>
                        <div class="notifications">
                            <i class="ph ph-bell"></i>
                            <span class="badge">3</span>
                        </div>
                    </div>
                </div>
            </header>

            <div class="admin-content">
                <div class="document-management">
                    <div class="document-header">
                        <h2>Document Tracking</h2>
                        <div class="document-actions">
                            <button class="btn btn-primary">
                                <i class="ph ph-plus"></i> Upload Document
                            </button>
                            <button class="btn btn-secondary">
                                <i class="ph ph-export"></i> Export
                            </button>
                        </div>
                    </div>

                    <div class="document-search">
                        <input type="text" placeholder="Search documents...">
                        <button class="btn btn-primary">
                            <i class="ph ph-magnifying-glass"></i> Search
                        </button>
                    </div>

                    <div class="document-filters">
                        <select>
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                        <select>
                            <option value="">All Types</option>
                            <option value="finance">Finance</option>
                            <option value="hr">Human Resources</option>
                            <option value="operations">Operations</option>
                        </select>
                        <select>
                            <option value="">All Departments</option>
                            <option value="finance">Finance</option>
                            <option value="hr">HR</option>
                            <option value="it">IT</option>
                        </select>
                    </div>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Reference No.</th>
                                    <th>Document Title</th>
                                    <th>Type</th>
                                    <th>Department</th>
                                    <th>Owner</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>DOC-2023-001</td>
                                    <td>Annual Financial Report</td>
                                    <td>Finance</td>
                                    <td>Accounting</td>
                                    <td>John Smith</td>
                                    <td><span class="badge bg-success">Approved</span></td>
                                    <td>15 Oct 2023</td>
                                    <td>
                                        <button class="btn btn-icon btn-sm btn-primary" title="View"><i class="ph ph-eye"></i></button>
                                        <button class="btn btn-icon btn-sm btn-info" title="Download"><i class="ph ph-download"></i></button>
                                        <button class="btn btn-icon btn-sm btn-warning" title="Edit"><i class="ph ph-pencil"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>DOC-2023-002</td>
                                    <td>HR Policy Update</td>
                                    <td>Policy</td>
                                    <td>Human Resources</td>
                                    <td>Sarah Johnson</td>
                                    <td><span class="badge bg-warning">Pending</span></td>
                                    <td>12 Oct 2023</td>
                                    <td>
                                        <button class="btn btn-icon btn-sm btn-primary" title="View"><i class="ph ph-eye"></i></button>
                                        <button class="btn btn-icon btn-sm btn-info" title="Download"><i class="ph ph-download"></i></button>
                                        <button class="btn btn-icon btn-sm btn-warning" title="Edit"><i class="ph ph-pencil"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>DOC-2023-003</td>
                                    <td>IT Infrastructure Proposal</td>
                                    <td>Proposal</td>
                                    <td>Information Technology</td>
                                    <td>Michael Brown</td>
                                    <td><span class="badge bg-danger">Rejected</span></td>
                                    <td>10 Oct 2023</td>
                                    <td>
                                        <button class="btn btn-icon btn-sm btn-primary" title="View"><i class="ph ph-eye"></i></button>
                                        <button class="btn btn-icon btn-sm btn-info" title="Download"><i class="ph ph-download"></i></button>
                                        <button class="btn btn-icon btn-sm btn-warning" title="Edit"><i class="ph ph-pencil"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4 d-flex justify-content-between align-items-center">
                        <div class="showing-entries">
                            Showing 1 to 3 of 24 entries
                        </div>
                        <div class="pagination">
                            <button class="btn btn-sm btn-outline-primary">Previous</button>
                            <button class="btn btn-sm btn-primary">1</button>
                            <button class="btn btn-sm btn-outline-primary">2</button>
                            <button class="btn btn-sm btn-outline-primary">3</button>
                            <button class="btn btn-sm btn-outline-primary">Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Sidebar toggle functionality
        document.querySelector('.sidebar-toggle').addEventListener('click', function() {
            document.querySelector('.admin-container').classList.toggle('sidebar-show');
        });

        // Simple tooltip functionality
        const tooltipElements = document.querySelectorAll('[title]');
        tooltipElements.forEach(el => {
            el.addEventListener('mouseenter', function() {
                const tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.textContent = this.getAttribute('title');
                document.body.appendChild(tooltip);
                
                const rect = this.getBoundingClientRect();
                tooltip.style.position = 'absolute';
                tooltip.style.left = `${rect.left + rect.width/2 - tooltip.offsetWidth/2}px`;
                tooltip.style.top = `${rect.top - tooltip.offsetHeight - 5}px`;
                tooltip.style.opacity = '1';
                
                this.addEventListener('mouseleave', () => {
                    tooltip.remove();
                });
            });
        });
    </script>
</body>
</html>
