<?php
namespace App\Controllers;

use App\Models\OfficeModel;
use App\Models\Document_StatusesModel;

class AdminController extends AdminSessionController
{

    public function dashboard()
    {
        return view('admin/dashboard'); // Show admin dashboard
    }
    public function sample ()
    {
        return view('admin/sample');
    }  
    // 💾 NEW: Save scanned document status to the database
    public function saveDocument()
    {
        $session = session();
        $documentsModel = new Document_StatusesModel();
    
        if ($this->request->isAJAX()) {
    
            $data = json_decode($this->request->getBody(), true);
    
            if (!$data || !isset($data['id'])) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Invalid document data.'
                ]);
            }
    
            if (!$session->get('Alogged_in')) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'You must be logged in to perform this action.'
                ]);
            }
    
            $saveData = [
                'document_id' => $data['id'],
                'received_by' => $session->get('department'),
                'received_at' => date('Y-m-d H:i:s'),
                'remarks' => isset($data['remarks']) ? $data['remarks'] : null
            ];
    
            if ($documentsModel->insert($saveData)) {
                return $this->response->setJSON([
                    'status' => 'success',
                    'message' => 'Document status saved successfully.'
                ]);
            } else {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Failed to save document status.'
                ]);
            }
        }
    
        return $this->response->setStatusCode(405); // Method Not Allowed if not POST
    }
  
    public function recent()
    {
        try {
            $session = session();
            $department = $session->get('department');  // Adjust if session holds the department
    
            if (!$department) {
                return $this->response->setJSON(['error' => 'User not logged in or department not found']);
            }
    
            $model = new Document_StatusesModel();
            $data = $model->getRecentDocumentsByDepartment($department);
    
            log_message('debug', 'Data Retrieved: ' . print_r($data, true));  // Log the data for debugging
    
            if (empty($data)) {
                return $this->response->setJSON(['message' => 'No recent documents found']);
            }
    
            return $this->response->setJSON($data);
    
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'error' => $e->getMessage()
            ]);
        }
    }    
    
    
}    
