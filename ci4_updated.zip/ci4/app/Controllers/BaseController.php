<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class BaseController extends Controller
{
    protected $session;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $this->session = session();

        // Routes that do not require login
        $allowedRoutes = [
            'login', // controller only
        ];

        // Get the current controller from the URL
        $currentController = strtolower(service('router')->controllerName());
        $currentController = explode('\\', $currentController); // e.g., App\Controllers\LoginController
        $currentController = strtolower(str_replace('controller', '', end($currentController)));

        // If user is not logged in and not accessing allowed controller, redirect
        if (!$this->session->get('logged_in') && !in_array($currentController, $allowedRoutes)) {
            header('Location: ' . base_url('login'));
            exit;
        }
    }
}
